import java.util.HashMap;

public class SAP {
    private Digraph G;

    // constructor takes a digraph (not necessarily a DAG)
    public SAP( Digraph G ) {
        this.G = G;
    }

    // length of shortest ancestral path between v and w; -1 if no such path
    public int length( int v, int w ) {
        int pathToV[] = new int[ G.V() ];
        int pathToW[] = new int[ G.V() ];

        int anc = shortestAncestor( v, w, pathToV, pathToW );
        if (anc == -1)
            return -1;

        return distance( v, w, anc, pathToV, pathToW );


        //return shortestAncestor2(v,w, 2,-1);
    }


    private int distance( int v, int w, int anc, int[] pathToV, int[] pathToW ) {
        if (v == w)
            return 0;

        int index = anc;
        int distance = 0;
        if (v == w) {
            return distance;
        }
        while (pathToV[ index ] != -1) {
            index = pathToV[ index ];
            distance++;
        }

        index = anc;
        while (pathToW[ index ] != -1) {
            index = pathToW[ index ];
            distance++;
        }

        return distance;
    }

    // a common ancestor of v and w that participates in a shortest ancestral path; -1 if no such path
    public int ancestor( int v, int w ) {
        if (v == w)
            return v;
        int pathToV[] = new int[ G.V() ];
        int pathToW[] = new int[ G.V() ];
        return shortestAncestor( v, w, pathToV, pathToW );
        //return shortestAncestor2(v,w, 1, -1);
    }


    // length of shortest ancestral path between any vertex in v and any vertex in w; -1 if no such path
    public int length( Iterable<Integer> v, Iterable<Integer> w ) {
        int shortestDist = -1;
        for (Integer vI : v) {
            for (Integer wI : w) {
                if (vI == wI) {
                    shortestDist = 0;
                    continue;
                }
                int pathToV[] = new int[ G.V() ];
                int pathToW[] = new int[ G.V() ];
                int anc = shortestAncestor( vI, wI, pathToV, pathToW );
                int dist = -1;
                if (anc != -1)
                    dist = distance( vI, wI, anc, pathToV, pathToW );

                if (dist < shortestDist || shortestDist == -1) {
                    shortestDist = dist;
                }
            }
        }
        return shortestDist;
    }

    // a common ancestor that participates in shortest ancestral path; -1 if no such path
    public int ancestor( Iterable<Integer> v, Iterable<Integer> w ) {
        int shortestPath = -1;
        int shortestAnc = -1;
        for (Integer vI : v) {
            for (Integer wI : w) {
                if (vI == wI) {
                    shortestPath = 0;
                    shortestAnc = vI;
                    continue;
                }
                int pathToV[] = new int[ G.V() ];
                int pathToW[] = new int[ G.V() ];

                int anc = shortestAncestor( vI, wI, pathToV, pathToW );
                int dist = -1;
                if (anc != -1)
                    dist = distance( vI, wI, anc, pathToV, pathToW );

                if (dist < shortestPath || shortestPath == -1) {
                    shortestPath = dist;
                    shortestAnc = anc;
                }
            }
        }
        return shortestAnc;
    }


    private int shortestAncestor( int v, int w, int[] pathToV, int[] pathToW ) {
        if (v == w) {
            return v;
        }
        Queue<Integer> queueV = new Queue<Integer>();
        Queue<Integer> queueW = new Queue<Integer>();
        HashMap<Integer, Character> visited = new HashMap<Integer, Character>();

        queueV.enqueue( v );
        queueW.enqueue( w );
        visited.put( v, 'v' );
        visited.put( w, 'w' );
        pathToV[ v ] = -1;
        pathToW[ w ] = -1;

        while (true) {
            if (!queueV.isEmpty()) {
                Integer vNode = queueV.dequeue();

                for (int vG : G.adj( vNode )) {
                    if (!visited.containsKey( vG )) {
                        visited.put( vG, 'v' );
                        queueV.enqueue( vG );
                        pathToV[ vG ] = vNode.intValue();
                    } else {
                        if (visited.get( vG ) == 'w') {

                            pathToV[ vG ] = vNode.intValue();
                            return vG;
                        } else {
                            // there's a loop do something
                        }
                    }
                }
            }

            if (!queueW.isEmpty()) {
                Integer wNode = queueW.dequeue();
                for (int wG : G.adj( wNode )) {
                    if (!visited.containsKey( wG )) {
                        visited.put( wG, 'w' );
                        queueW.enqueue( wG );
                        pathToW[ wG ] = wNode.intValue();

                    } else {
                        if (visited.get( wG ) == 'v') {

                            pathToW[ wG ] = wNode.intValue();
                            return wG;
                        } else {
                            // there's a loop do something
                        }
                    }
                }

            }
            if (queueW.isEmpty() && queueV.isEmpty()) {
                break;
            }

        }
        return -1;

    }

    // do unit testing of this class
    public static void main( String[] args ) {
        In in = new In( args[ 0 ] );
        Digraph G = new Digraph( in );
        SAP sap = new SAP( G );
        while (!StdIn.isEmpty()) {
            int v = StdIn.readInt();
            int w = StdIn.readInt();
            int length = sap.length( v, w );
            int ancestor = sap.ancestor( v, w );
            StdOut.printf( "length = %d, ancestor = %d\n", length, ancestor );
        }
    }
}