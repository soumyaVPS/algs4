import java.util.NoSuchElementException;
import java.lang.UnsupportedOperationException;
import java.lang.NullPointerException;
import java.lang.Iterable;
import java.util.Iterator;
public class RandomizedQueue<Item> implements Iterable<Item> {
	private Item array[];
	private int numItems;
	private int beg;
	private int end;
   
   public RandomizedQueue()    {       // construct an empty randomized queue
	   array = (Item[]) new Object[1];
   }
   public boolean isEmpty()      {     // is the queue empty?
	   return numItems==0;
   }
   public int size()          {        // return the number of items on the queue
	   return numItems;
   }
   
   public void enqueue(Item item)  {   // add the item
       if (item == null) {
            throw new NullPointerException();
       }
	   int N = array.length;
	   if (N <= numItems) {
		   resize(2*numItems);
	   }
	   int r = StdRandom.uniform(numItems+1);
       //StdOut.println(r+" th position is" + getRthPos(r));
       int rthpos = getRthPos(r);
	   Item itemR = array [rthpos];
	   array[r] = item;
       if (rthpos != r || itemR!= null )
            array[numItems] = itemR;
	   numItems++;
       //StdOut.println("!!!!numItems "+ numItems);
       
	    //for (int i=0;i<array.length;i++) StdOut.print(" " +array[i]);
      
	   if (end >= N) 
		   end = 0;
	   else 
		   end++;
	      
   }
   
   private int getRthPos(int r) {
	   int pos = beg + r;
	   if (pos >= array.length)
		   pos -= array.length;
	   return pos;
   }
   
   private void resize(int capacity)
   {
	   Item[] copy =(Item[]) new Object[capacity];
	   //StdOut.println("Array is ");
       //for (int i=0;i<array.length;i++) StdOut.println(array[i]);
       
	   for (int i = 0; i < numItems; i++) {
           //StdOut.println("Resize " + getRthPos(i));
		   copy[i] = array[getRthPos(i)];
           //StdOut.println(copy[i] + " copy of i");
       }
       
	   array = copy;
	   beg = 0;
	   end = numItems;
   }
   public Item dequeue() {             // delete and return a random item
       if (numItems <1) {
            throw new NoSuchElementException();
       }
	   Item item = array[beg];
	   array[beg] = null;
	   if (beg < array.length) {
		   beg++;
	   } else beg = 0;
	   numItems --;
	   if (numItems > 0 && numItems == array.length/4) 
		   resize(array.length/2);
	   
	   return item;
   }
   
   public Item sample(){               // return (but do not delete) a random item
       int index = StdRandom.uniform(numItems+1) + beg;
       if (index > array.length) 
            index = index - array.length;
       
	   return array[index];
   }
   
   private class  QueIterator implements Iterator<Item> {
	   int currIndex, end, size;
	   
	   QueIterator (int currIndex, int end, int size) {
		   this.currIndex = currIndex;
		   this.end = end;
		   this.size = size;
           //StdOut.println ("QueIterator currIndex, end,size "+currIndex + " " +this.end + " " + this.size);
	   }
	   
	   public boolean hasNext() {
		   return  (size != 0); 
		   
	   }
	   public Item next() throws NoSuchElementException{
		   if (size == 0)
			   throw new NoSuchElementException();		   
		   Item it = array[currIndex]; 
		   size --;
		   if (currIndex >= array.length && size >0) {
			  currIndex = 0;
		   } else 
			   currIndex++;
		   return it;
	   }
	   
	   public void remove() {
		   throw new UnsupportedOperationException();
	   }
   }
   public Iterator<Item> iterator() {  // return an independent iterator over items in random order
	   return new QueIterator(beg, end, numItems);
   }
}