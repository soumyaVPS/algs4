
import java.util.Iterator;

public class Subset {

    /*public static void main(String[] args) {

        StdOut.print( "aaa" );

        Deque<Integer> deque = new Deque<Integer>();

        deque.addLast( 1 );
        deque.removeLast();
        deque.addFirst( 3 );
        deque.addFirst( 4 );
        deque.addFirst( 5 );
        deque.addLast( 6 );
        deque.removeFirst();
        deque.addLast( 8 );
        deque.addLast( 9 );
    }*/
    public static void main( String[] args ) {

        StdOut.print( "aaa" );

        RandomizedQueue<Integer> rq = new RandomizedQueue<Integer>();
        StdOut.println(rq.size());
        StdOut.println(rq.isEmpty());
                int num = 500;
        for (int i = 0; i <50;i++) {
        try {
            if (StdRandom.uniform(2)==1) 
                rq.enqueue(num++);
            else 
                StdOut.println(rq.dequeue());
           } catch (Exception e) {StdOut.println(e);}
           
        }
       Iterator<Integer> it = rq.iterator();
        while (it.hasNext()) {
            StdOut.println(it.next());
        }

    }
}